
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           DATA PREPROCESSING                            &
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This example contains cells that call functions to batch process motion 
% capture data collected at the UMass biomechanics laboratory. The example
% provided compares three trials of walking data of a person with 
% unilateral amputation using a passive prosthesis to three trials of the 
% person walking with the UMass Active Alignment Prosthesis. Make note of
% the file organization in the current directory, and how it is modified
% while working through this analysis example. The functions in the OSMTK
% are designed for recorded datasets to be organized as shown, with file
% names that are appropriate for the dataset and trial. Quallysis .tsv
% files must be exported with the ENTIRE time series after gap-filling the
% marker trajectories, and organized in separate folders containing the
% trial data for each test condition as provided in the TSV folder. This is
% necessary for synchronizing pressure data with motion capture daya. 
% Analyses that require specific setup files should have their own setup
% folders as provided in the COM, ID and IK folders. Pressure data for each
% test condition and models for each test condition should also have their
% own folders. Analisys and comparisons can be expanded for as many test
% conditions and trials needed. 
%
% It is intended that you use this as an example to develope your own
% processing files that are specific to your research. 
%
% After downloading the UMass OSMTK, add the Functions folder to the MATLAB
% path by running pathtool in the command window. 
%
% For more information on following functions used, type 'help ' followed 
% by the OSMTK function name in the command window.
% 
% written by Andrew LaPre
% last modified 3/2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clc
clear all
close all


%% get subject mass from calibration files
% Calculated mass is saved in subjectMass.mat.

% Point to the directory containing the calibration .tsv files for each
% test condition to calculate the subjects recorded mass. This requires
% that the force plates were zeroed before recording calibration
% measurements.
datafolder{1} = [pwd '\TSV\Calibration\GRF_Passive\'];
datafolder{2} = [pwd '\TSV\Calibration\GRF_Active\'];
getMass(datafolder);

clear datafolder

%% zero GRF data to remove baseline offset
% This is helpful if you forget to zero the force plates during recording.

% passive
data_folder = [pwd '\TSV\Passive\GRF\'];
zeroGRF(data_folder)
% active 
data_folder = [pwd '\TSV\Active\GRF\'];
zeroGRF(data_folder)

clear datafolder

%% get frame times from GRF data
% This requires that you export the FULL TIMELINE from QTM. 
close all

% Point to the directory containing the original GRF files with the analog
% input _a.tsv file. This is necesarry for synchronizing the novel pressure
% files. The analog file contains the trigger pulse from the novel module. 

% passive
data_folder = [pwd '\TSV\Passive\GRF\'];
frames.passive = frameFinder(data_folder);
% active 
data_folder = [pwd '\TSV\Active\GRF\'];
frames.active = frameFinder(data_folder); 

% manually fix some frames after visual inspection of generated plots
frames.active(3,6) = 23530;

save frames.mat frames

clear data_folder frames

%% trim GRF data to remove unwanted data outside of the frames of interest
% Now point to the zeroed data to trim it based on the frames just
% calculated.

% passive
load frames.mat
Frames = frames.passive;
data_folder = 'TSV\Passive\GRF_Zeroed\';
trimGRF(data_folder, Frames)
% active
clear Frames
Frames = frames.active;
data_folder = 'TSV\Active\GRF_Zeroed\';
trimGRF(data_folder, Frames)

clear data_folder Frames 

%% now trim marker data

load frames.mat
% passive
clear Frames
Frames = frames.passive;
data_folder = 'TSV\Passive\MarkerData\';
trimMarkerData(data_folder, Frames)
% active
clear Frames
Frames = frames.active;
data_folder = 'TSV\Active\MarkerData\';
trimMarkerData(data_folder, Frames)

clear data_folder Frames

%% convert marker qtm .tsv files to opensim .trc format
% this will take several minutes!

close all
clear all
clc

% passive
data_folder = 'TSV\Passive\MarkerData_Trimmed\';
write_folder = 'TRC_MarkerData\Passive\';
TSV_TRC_batch(data_folder, write_folder)

% active
data_folder = 'TSV\Active\MarkerData_Trimmed\';
write_folder = 'TRC_MarkerData\Active\';
TSV_TRC_batch(data_folder, write_folder)

% calibration
data_folder = 'TSV\Calibration\MarkerData\';
write_folder = 'TRC_MarkerData\Calibration\';
TSV_TRC_batch(data_folder, write_folder)

clear data_folder write_folder

%% convert GRF .tsv files to .mot

clear all
close all
clc

% passive
options.newName{1} = 'Passive_0002';
options.newName{2} = 'Passive_0003';
options.newName{3} = 'Passive_0005';
options.TSVfolder = [pwd '\TSV\Passive\GRF_Zeroed_Trimmed\'];
options.writeFolder = [pwd '\GRFdata\Passive\'];
options.leftPlate = [0,1,0,0,0];
options.output = 1;
options.autoCut = 'Yes';

GRF_tsv2mot_batch(options)

% active 
clear 
close all
options.newName{1} = 'Active_0001';
options.newName{2} = 'Active_0002';
options.newName{3} = 'Active_0003';
options.TSVfolder = [pwd '\TSV\Active\GRF_Zeroed_Trimmed\'];
options.writeFolder = [pwd '\GRFdata\Active\'];
options.leftPlate = [0,1,0,0,0]; % which plates (1-5) have left foot contact
options.output = 1;
options.autoCut = 'Yes';
GRF_tsv2mot_batch(options)

clear options

%% prescale model

clear all
close all
clc

options.modelFolder = 'Models\';
options.limbRatio = .59;                        % amputated/intact-limb length ratio
options.SocketRefPlacement = .25;               % from distal tip
options.version = '3.3';                        % OpenSim version: 3.3 or 4.0
% passive model
options.model = 'TTAmp_Left_passive.osim';      % generic model name
options.newName = 'A07_passive_prescaled.osim'; % new model name 
modelPreScale(options);                         % run the tool
% active model
options.model = 'TTAmp_Left_AAP-Proto1.osim';
options.newName = 'A07_active_prescaled.osim';
modelPreScale(options);

clear all

%% scale model

% passive and active model must be scaled using OpenSim or alternative 
% methods, saving the files and adding to the model directory







