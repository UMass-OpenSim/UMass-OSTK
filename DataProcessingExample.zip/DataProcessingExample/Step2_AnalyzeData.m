
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                             DATA ANALYSES                               &
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This script contains cells that call functions to batch analyzes
% preprocessed biomechanics data.
%
% You must first run all cells in step 1!
%
% For more information on following functions used, type 'help ' followed 
% by the OSMTK function name in the command window.
% 
% written by Andrew LaPre
% last modified 3/2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all
clc

passiveModel = 'A07_passive_autoScaled_longrun20.osim';
activeModel = 'A07_active_autoScaled.osim';

%% %%%%%%%%%%%%%%%%%%%%%%%% batch inverse kinematics analysis 

% passive pref
IK_options.model_pth = ([pwd '\Models\']);
IK_options.model = passiveModel;
IK_options.trcData_pth = ([pwd '\TRC_MarkerData\Passive\']);
IK_options.setup_pth = ([pwd '\IK\Setup\']);
IK_options.genericSetupForIK = 'IKsetup.xml';
IK_options.results_pth = ([pwd '\IK\Results\Passive\']);
IK_options.amputated_side = 'left';
IK_options.activeAlignment = 'No';
IK_batch(IK_options)

%% active pref (alignment coefficient = 2.5)
IK_options.model_pth = ([pwd '\Models\']);
IK_options.model = activeModel;
IK_options.trcData_pth = ([pwd '\TRC_MarkerData\Active\']);
IK_options.setup_pth = ([pwd '\IK\Setup\']);
IK_options.genericSetupForIK = 'IKsetup.xml';
IK_options.results_pth = ([pwd '\IK\Results\Active\']);
IK_options.amputated_side = 'left';
IK_options.activeAlignment = 'Yes';
IK_batch(IK_options)

%% %%%%%%%%%%%%%%%%%%%%%%%% batch inverse dynamics
% passive_pref
ID_options.model_pth = ([pwd '\Models\']);
ID_options.model = passiveModel;
ID_options.IKresults_pth = ([pwd '\IK\Results\Passive\']);
ID_options.setup_pth = ([pwd '\ID\Setup\']);
ID_options.genericSetupForID = 'IDsetup.xml';
ID_options.extForces = 'ExtForces.xml';
ID_options.grfData_pth = ([pwd '\GRFdata\Passive\']);
ID_options.results_pth = ([pwd '\ID\Results\Passive\']);
ID_options.amputated_side = 'left';
ID_options.activeAlignment = 'No';
ID_batch(ID_options)

%% active pref
ID_options.model_pth = ([pwd '\Models\']);
ID_options.model = activeModel;
ID_options.IKresults_pth = ([pwd '\IK\Results\Active\']);
ID_options.setup_pth = ([pwd '\ID\Setup\']);
ID_options.genericSetupForID = 'IDsetup.xml';
ID_options.extForces = 'ExtForces.xml';
ID_options.grfData_pth = ([pwd '\GRFdata\Active\']);
ID_options.results_pth = ([pwd '\ID\Results\Active\']);
ID_options.amputated_side = 'left';
ID_options.activeAlignment = 'Yes';
ID_batch(ID_options)

%% %%%%%%%%%%%%%%%%%%%%%%%% batch power analysis
% passive
close all
clear options
options.IKdatasets{1} = 'IK\Results\Passive\';
options.IKdatasets{2} = 'IK\Results\Active\';
options.IDdatasets{1} = 'ID\Results\Passive\';
options.IDdatasets{2} = 'ID\Results\Active\';
options.results_pth{1} = ([pwd '\POW\Passive\']);
options.results_pth{2} = ([pwd '\POW\Active\']);
options.filter = 15;
options.linearcoordinates = [4, 5, 6, 22];
POW_batch(options)

%% %%%%%%%%%%%%%%%%%%%%%%%% Center of Mass Analysis

clear options

% passive
options.model_pth = ([pwd '\Models\']);
options.model = passiveModel;
options.results_pth = ([pwd '\COM\Results\Passive\']);
options.setup_pth = ([pwd '\COM\Setup\']);
options.IKresults_pth = ([pwd '\IK\Results\Passive\']);
COM_batch(options)

% active 
options.model_pth = ([pwd '\Models\']);
options.model = activeModel;
options.results_pth = ([pwd '\COM\Results\Active\']);
options.setup_pth = ([pwd '\COM\Setup\']);
options.IKresults_pth = ([pwd '\IK\Results\Active\']);
COM_batch(options)


%% analyze pressure data
% this function may need to be modified for different sensor combinations

load frames.mat
clear options
% add as many folders as you want
options.dataSets{1} = [pwd '\Pressure\Passive\'];
options.dataSets{2} = [pwd '\Pressure\Active\'];
options.Frames{1} = frames.passive;
options.Frames{2} = frames.active;
options.label{1} = 'Passive';
options.label{2} = 'Active Alignment';
options.outputLevel = 2;
options.matchOffset = 'Yes';
% in case of sensor failure
options.omit{1} = [0; 0; 0];
options.omit{2} = [0; 0; 1];
options.filter = 5;

getPressureAvgs(options);

load('pressureData.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%% get GRF averages

clc
close all
clear options
load frames.mat
% add as many folders as you want
options.datasets{1} = [pwd '\GRFdata\Passive\'];
options.datasets{2} = [pwd '\GRFdata\Active\'];
options.label{1} = 'Passive Pref';
options.label{2} = 'Active Pref';
options.Frames{1} = frames.passive;
options.Frames{2} = frames.active;
options.outputLevel = 2;
options.filter = 5;
options.subjectMass{1} = 73.16;
options.subjectMass{2} = 74.28;
options.norm2mass = 'yes';


combineGRF(options);
clear 
% load combinedGRF.mat


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                   INSPECT
%
% The following cells utilize a powerful function that allows you to
% quickly compare datasets after processing in the manner prescribed. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%%% compare COM results 

% modify and run this cell after IK
clear options
% close all
clc
% add as many datasets as you want
options.datasets{1} = 'COM\Results\Passive\';
options.datasets{2} = 'COM\Results\Active\';
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 5;  % filter window size
options.outputLevel = 2;
options.dataType = 'COM';         % IK ,ID, or COM
options.stitchData = 'n';       % stitch heel strike to heel strike if the contralateral limb. 
options.norm2mass = 'no';
options.zeroCOM = 'yes';

% enter the coordinate to compare
options.tag = 'center_of_mass_Y'; 
% options.tag = 'torso_Y'; 
compareResults(options)


%% %%%%%%%%%%%%%%%%%%%%%%%% compare IK results 
%%%%%%%%%%%%%%%%%%%%%
% modify and run this cell after IK
clear options
close all
clc
% add as many datasets as you want
options.datasets{1} = 'IK\Results\Passive\';
options.datasets{2} = 'IK\Results\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 10;  % filter window size
options.outputLevel = 2;
options.dataType = 'IK';            % IK or ID
options.stitchData = 'n';           % stitch heel strike to heel strike if the contralateral limb
options.zero = 'no';
options.norm2mass = 'no';

%% pelvis tilt 
options.removeOffset = 'n';
options.stitchData = 'n';
% options.removeOffset = 'yes';
options.tag = 'pelvis_tilt'; 
compareResults(options)

%% socket flexion 
options.removeOffset = 'n';
options.stitchData = 'n';
% options.removeOffset = 'yes';
options.tag = 'socket_flexion'; 
compareResults(options)

%% socket pistoning 
options.removeOffset = 'y';
options.stitchData = 'n';
% options.removeOffset = 'yes';
options.tag = 'socket_ty'; 
compareResults(options)

%% ankle and foot flexion
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'ankle_angle_r';
compareResults(options)

options.removeOffset = 'n';
options.stitchData = 'n';
options.tag = 'foot_flex';  
compareResults(options)

%% knee flexion
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r';  
compareResults(options)
ylim([-10 80]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'knee_angle_l';  
compareResults(options)
ylim([-10 80]);

%% hip flexion
options.mirror = 'n';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r';  
compareResults(options)
ylim([-40 50]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l';  
compareResults(options)
ylim([-40 50]);


%% %%%%%%%%%%%%%%%%%%%%%%%%% compare ID results 
%%%%%%%%%%%%%%%%%%%%%
% first we set up the options that will apply to most of the data
clear options
close all
clc
% add as many datasets as you want
options.datasets{1} = 'ID\Results\Passive\';
options.datasets{2} = 'ID\Results\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 20;  % filter window size
options.outputLevel = 2; 
options.dataType = 'ID';         % IK or ID
options.stitchData = 'n';
options.norm2mass = 'y';
options.zero = 'no';
options.subjectMass{1} = 73.16;
options.subjectMass{2} = 74.28;

%% socket flexion moment and socket pistoning force
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'socket_flexion_moment'; 
compareResults(options)

options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'socket_ty_force'; 
compareResults(options)

%% ankle and foot flexion moment
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'ankle_angle_r_moment';
compareResults(options)
%
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'foot_flex_moment';  
compareResults(options)

%% knee flexion moment
options.mirror = 'n';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r_moment';  
compareResults(options)
% ylim([-80 0]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'knee_angle_l_moment';  
compareResults(options)

%% hip flexion moment
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r_moment';  
compareResults(options)
% ylim([-30 50]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l_moment';  
compareResults(options)
% ylim([-30 50]);

%% %%%%%%%%%%%%%%%%%%%%%%%%% compare POWER results 
%%%%%%%%%%%%%%%%%%%%%
% setup the options first
clear options
close all
clc
% add as many datasets as you want
options.datasets{1} = 'POW\Passive\';
options.datasets{2} = 'POW\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 10;  % filter window size
options.outputLevel = 2; 
options.dataType = 'POW';         % IK, ID, or POW
options.stitchData = 'n';
options.zero = 'no';
options.subjectMass{1} = 73.16;
options.subjectMass{2} = 74.28;
options.norm2mass = 'yes';


%% ankle and foot flexion power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'ankle_angle_r_power';
compareResults(options)
%
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'foot_flex_power';  
compareResults(options)

%% knee flexion power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r_power';  
compareResults(options)
% ylim([-80 0]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'knee_angle_l_power';  
compareResults(options)

%% hip flexion power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r_power';  
compareResults(options)
% ylim([-30 50]);

options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l_power';  
compareResults(options)
% ylim([-30 50]);

