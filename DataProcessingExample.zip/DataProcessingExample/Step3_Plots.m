
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                           GENERATE PLOTS                                &
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This script contains cells that call functions generate and store 
% statistics of analyzed data, followed by plots of example data for a
% comprehensive analysis. Use this as a guide for your own project!
%
% You must first run all cells in Step 1 and Step 2!
%
%
% For more information on following functions used, type 'help ' followed 
% by the OSMTK function name in the command window.
% 
% written by Andrew LaPre
% last modified 3/2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
close all

% prepare and store data statistics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% IK 
clear options
options.datasets{1} = 'IK\Results\Passive\';
options.datasets{2} = 'IK\Results\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 10;  % filter window size
options.outputLevel = 1;
options.dataType = 'IK';        
options.stitchData = 'n';   
options.norm2mass = 'no';

% socket kinematics
%flexion 
options.removeOffset = 'y';
options.stitchData = 'n';
% options.removeOffset = 'yes';
options.tag = 'socket_flexion'; 
compareResults(options)
load compResults.mat
data.IK.SocketFlex = compResults;
% pistoning
options.removeOffset = 'y';
options.stitchData = 'n';
% options.removeOffset = 'yes';
options.tag = 'socket_ty'; 
compareResults(options)
load compResults.mat
data.IK.SocketPist = compResults;

% ankle and foot prosthesis kinematics
options.removeOffset = 'no';
options.stitchData = 'y';
options.mirror = 'n';  
options.tag = 'ankle_angle_r';
compareResults(options)
load compResults.mat
data.IK.AnkleFlex = compResults;
options.removeOffset = 'n';
options.stitchData = 'n';
options.mirror = 'n';
options.tag = 'foot_flex';  
compareResults(options)
load compResults.mat
data.IK.ProsFootFlex = compResults;

% knee kinematics
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r';
compareResults(options)
load compResults.mat
data.IK.KneeFlexionR = compResults;
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'knee_angle_l';  
compareResults(options)
load compResults.mat
data.IK.KneeFlexionL = compResults;

% hip kinematics
options.mirror = 'n';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r';  
compareResults(options)
load compResults.mat
data.IK.HipFlexionR = compResults;
options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l';  
compareResults(options)
load compResults.mat
data.IK.HipFlexionL = compResults;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ID
options.datasets{1} = 'ID\Results\Passive\';
options.datasets{2} = 'ID\Results\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 10;  % filter window size
options.outputLevel = 1; 
options.dataType = 'ID';         
options.stitchData = 'n';
options.norm2mass = 'y';
options.subjectMass{1} = 73.16;
options.subjectMass{2} = 74.28;

% socket dynamics
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'socket_flexion_moment'; 
compareResults(options)
load compResults.mat
data.ID.SocketFlexMom = compResults;
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'socket_ty_force'; 
compareResults(options)
load compResults.mat
data.ID.SocketPistF = compResults;

% ankle and foot prosthesis dynamics
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'ankle_angle_r_moment';
compareResults(options)
load compResults.mat
data.ID.AnkleFlexMom = compResults;
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'foot_flex_moment';  
compareResults(options)
load compResults.mat
data.ID.ProsFootFlexMom = compResults;

% knee dynamics
options.mirror = 'n';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r_moment';  
compareResults(options)
load compResults.mat
data.ID.KneeFlexMomR = compResults;
options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'knee_angle_l_moment';  
compareResults(options)
load compResults.mat
data.ID.KneeFlexMomL = compResults;

% hip dynamics
options.mirror = 'y';
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r_moment';  
load compResults.mat
data.ID.HipFlexionMomR = compResults;
compareResults(options)
options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l_moment';  
compareResults(options)
load compResults.mat
data.ID.HipFlexionMomL = compResults;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% power
options.datasets{1} = 'POW\Passive\';
options.datasets{2} = 'POW\Active\';
load frames.mat
options.frames{1} = frames.passive;
options.frames{2} = frames.active;
options.label{1} = 'Passive Pref AutoScaled';
options.label{2} = 'Active Pref AutoScaled';
options.filter = 10;  
options.outputLevel = 1; 
options.mirror = 'n';
options.dataType = 'POW';        
options.stitchData = 'n';
options.subjectMass{1} = 73.16;
options.subjectMass{2} = 74.28;
options.norm2mass = 'yes';
option.integrate = 'yes'; 

% socket flexion power
options.removeOffset = 'no';
options.stitchData = 'n';
options.mirror = 'n';
options.tag = 'socket_flexion_power';
compareResults(options)
load compResults.mat
data.POW.SocketFlexPow = compResults;
% socket pistoning power
options.removeOffset = 'no';
options.stitchData = 'n';
options.mirror = 'n';
options.tag = 'socket_ty_power';  
compareResults(options)
load compResults.mat
data.POW.SocketPistPow = compResults;

% ankle power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'ankle_angle_r_power';
compareResults(options)
load compResults.mat
data.POW.AnklePow = compResults;
% rerun without stitching data 
options.stitchData = 'n';
compareResults(options);
load compResults.mat
data.POWcomb.AnklePow = compResults; 
% foot prosthesis power
options.removeOffset = 'no';
options.stitchData = 'n';
options.tag = 'foot_flex_power';  
compareResults(options)
load compResults.mat
data.POW.ProsFootPow = compResults;

% knee right power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'knee_angle_r_power';  
compareResults(options)
load compResults.mat
data.POW.KneePowR = compResults;
options.stitchData = 'n';
compareResults(options);
load compResults.mat
data.POWcomb.KneePowR = compResults; 
% knee l power
options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'knee_angle_l_power';  
compareResults(options)
load compResults.mat
data.POW.KneePowL = compResults;
data.POWcomb.KneePowL = compResults; 

% hip r power
options.removeOffset = 'no';
options.stitchData = 'y';
options.tag = 'hip_flexion_r_power';  
compareResults(options)
load compResults.mat
data.POW.HipPowR = compResults;
options.stitchData = 'n';
compareResults(options);
load compResults.mat
data.POWcomb.HipPowR = compResults; 
% hip l power
options.removeOffset = 'no';
options.stitchData = 'n'; 
options.tag = 'hip_flexion_l_power';  
compareResults(options)
load compResults.mat
data.POW.HipPowL = compResults;
data.POWcomb.HipPowL = compResults;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% COM
options.datasets{1} = 'COM\Results\Passive\';
options.datasets{2} = 'COM\Results\Active\';
options.filter = 1;  
options.outputLevel = 2;
options.dataType = 'COM';        
options.stitchData = 'n';
options.norm2mass = 'no';
options.mirror = 'no';
options.zeroCOM = 'yes';

% % torso and combined
% options.tag = 'torso_Y'; 
% compareResults(options)
% load compResults.mat
% data.COM.TorsoCOM = compResults;
options.tag = 'center_of_mass_Y'; 
compareResults(options)
load compResults.mat
data.COM.CombinedCOM = compResults;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% pressure 
load pressureData.mat
data.Pressure = pressure;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GRF
load combinedGRF.mat
data.GRF = GRFdata;
%%
save A07_Data_Complete.mat data

%% load subject data
clear all
close all
clc

load A07_Data_Complete.mat

%% WB grid plot
% left and right overlaid, no SD bounds
% put peaks and SD in table
clc
% close all

stance = 0:1:100;

figure('OuterPosition',[20 20 550 750])
% ankle/foot IK
subplot(4,3,1)
hold on
plot(stance,data.IK.ProsFootFlex{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.IK.AnkleFlex{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.IK.ProsFootFlex{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.IK.AnkleFlex{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
title('Ankle/Prosthetic Foot', 'FontSize',10)
ylabel('Angle (deg)', 'FontSize',10)

% knee IK
subplot(4,3,2)
hold on
plot(stance,data.IK.KneeFlexionL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.IK.KneeFlexionR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.IK.KneeFlexionL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.IK.KneeFlexionR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
title('Knee', 'FontSize',10)
% hip IK
subplot(4,3,3)
hold on
plot(stance,data.IK.HipFlexionL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.IK.HipFlexionR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.IK.HipFlexionL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.IK.HipFlexionR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
title('Hip', 'FontSize',10)

% ankle/foot ID
subplot(4,3,4)
hold on
plot(stance,data.ID.ProsFootFlexMom{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.ID.AnkleFlexMom{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.ID.ProsFootFlexMom{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.ID.AnkleFlexMom{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
ylabel('Moment (N-m/kg)', 'FontSize',10)
% knee ID
subplot(4,3,5)
hold on
plot(stance,data.ID.KneeFlexMomL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.ID.KneeFlexMomR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.ID.KneeFlexMomL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.ID.KneeFlexMomR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
% hip ID
subplot(4,3,6)
hold on
plot(stance,data.ID.HipFlexionMomL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.ID.HipFlexionMomR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.ID.HipFlexionMomL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.ID.HipFlexionMomR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])

% ankle/foot POW
subplot(4,3,7)
hold on
plot(stance,data.POW.ProsFootPow{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.POW.AnklePow{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.POW.ProsFootPow{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.POW.AnklePow{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
ylabel('Power (W/kg)', 'FontSize',10)
xlabel('% Gait', 'FontSize',10)
% knee POW
subplot(4,3,8)
hold on
plot(stance,data.POW.KneePowL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.POW.KneePowR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.POW.KneePowL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.POW.KneePowR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
xlabel('% Gait', 'FontSize',10)
legend('ESR','Intact ESR','AAP','Intact AAP','Orientation','horizontal','Location','South')
% hip POW
subplot(4,3,9)
hold on
plot(stance,data.POW.HipPowL{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.POW.HipPowR{2,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5],'LineStyle',':')
plot(stance,data.POW.HipPowL{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
plot(stance,data.POW.HipPowR{3,3}(:,1),'LineWidth',2.0,'Color',[0.5, 0.5, 0.5])
xlabel('% Gait', 'FontSize',10)

% add letters to plot
for ii = 1:9
    subplot(4,3,ii)
    if (ii == 1)
        yy = 20;
    end
    if (ii == 2)
        yy = 100;
    end
    if (ii == 3)
        yy = 50;
    end
    if (ii == 4)
        yy = 2;
    end
    if (ii == 5)
        yy = 2;
    end
    if (ii == 6)
        yy = 1;
    end
    if (ii == 7)
        yy = 4;
    end
    if (ii == 8)
        yy = 2;
    end
    if (ii == 9)
        yy = 2;
    end
    text(100,yy,['(',char(ii+96),') '],...
        'HorizontalAlignment','right',...
        'VerticalAlignment','top',...
        'color','r',...
        'fontw','b')
end

%% combined power
clc
% close all

stance = 0:1:100;

PassivePwrSum = data.POWcomb.AnklePow{2,3}(:,1)+data.POWcomb.KneePowL{2,3}(:,1)+data.POWcomb.KneePowR{2,3}(:,1)+data.POWcomb.HipPowL{2,3}(:,1)+data.POWcomb.HipPowR{2,3}(:,1);
ActivePwrSum = data.POWcomb.AnklePow{3,3}(:,1)+data.POWcomb.KneePowL{3,3}(:,1)+data.POWcomb.KneePowR{3,3}(:,1)+data.POWcomb.HipPowL{3,3}(:,1)+data.POWcomb.HipPowR{3,3}(:,1);
figure
hold on
plot(stance, PassivePwrSum,'LineWidth',3,'Color',[0 0 0],'LineStyle',':')
plot(stance, ActivePwrSum,'LineWidth',3,'Color',[0 0 0])
title('Rest of Body Power','FontSize',20)
ylabel('Normalized Power (Watts/kg)', 'FontSize',14)
xlabel('% Gait', 'FontSize',14)
legend('ESR data','AAP data','Location','SouthEast')

PassivePwrSum = data.POW.AnklePow{2,3}(:,1)+data.POW.KneePowL{2,3}(:,1)+data.POW.KneePowR{2,3}(:,1)+data.POW.HipPowL{2,3}(:,1)+data.POW.HipPowR{2,3}(:,1);
ActivePwrSum = data.POW.AnklePow{3,3}(:,1)+data.POW.KneePowL{3,3}(:,1)+data.POW.KneePowR{3,3}(:,1)+data.POW.HipPowL{3,3}(:,1)+data.POW.HipPowR{3,3}(:,1);
figure
hold on
plot(stance, PassivePwrSum,'LineWidth',3,'Color',[0 0 0],'LineStyle',':')
plot(stance, ActivePwrSum,'LineWidth',3,'Color',[0 0 0])
title('Phase Synced Rest of Body Power','FontSize',20)
ylabel('Normalized Power (Watts/kg)', 'FontSize',14)
xlabel('% Gait', 'FontSize',14)
legend('ESR data','AAP data','Location','SouthEast')

% combined net positive work
PassiveNetPosWrk = data.POW.AnklePow{2,9}(1)+data.POW.KneePowL{2,9}(1)+data.POW.KneePowR{2,9}(1)+data.POW.HipPowL{2,9}(1)+data.POW.HipPowR{2,9}(1)
ActiveNetPosWrk = data.POW.AnklePow{3,9}(1)+data.POW.KneePowL{3,9}(1)+data.POW.KneePowR{3,9}(1)+data.POW.HipPowL{3,9}(1)+data.POW.HipPowR{3,9}(1)
% combined net work
PassiveNetWrk = data.POW.AnklePow{2,11}(1)+data.POW.KneePowL{2,11}(1)+data.POW.KneePowR{2,11}(1)+data.POW.HipPowL{2,11}(1)+data.POW.HipPowR{2,11}(1)
ActiveNetWrk = data.POW.AnklePow{3,11}(1)+data.POW.KneePowL{3,11}(1)+data.POW.KneePowR{3,11}(1)+data.POW.HipPowL{3,11}(1)+data.POW.HipPowR{3,11}(1)


%% socket grid plot
clc
close all

stance = 0:1:100;

% figure('OuterPosition',[20 20 1100 850])
figure('OuterPosition',[20 20 550 700])
% socket flexion IK
subplot(3,2,1)
hold on
plot(stance,data.IK.SocketFlex{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.IK.SocketFlex{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
title('Socket Flexion/Extension', 'FontSize',10)
ylabel('Angle (deg)', 'FontSize',10)
% socket pistoning IK
subplot(3,2,2)
hold on
plot(stance,data.IK.SocketPist{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.IK.SocketPist{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
title('Socket Pistoning', 'FontSize',10)
ylabel('Translation (m)', 'FontSize',10)
% socket flexion ID
subplot(3,2,3)
hold on
plot(stance,data.ID.SocketFlexMom{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.ID.SocketFlexMom{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
ylabel('Moment (N-m/kg)', 'FontSize',10)
% socket pistoning ID
subplot(3,2,4)
hold on
plot(stance,data.ID.SocketPistF{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.ID.SocketPistF{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
ylabel('Force (N/kg)', 'FontSize',10)

% socket flexion POW
subplot(3,2,5)
hold on
plot(stance,data.POW.SocketFlexPow{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.POW.SocketFlexPow{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
ylabel('Power (W/kg)', 'FontSize',10)
xlabel('% Gait', 'FontSize',10)
% socket pistoning ID
subplot(3,2,6)
hold on
plot(stance,data.POW.SocketPistPow{2,3}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.POW.SocketPistPow{3,3}(:,1),'LineWidth',2.0,'Color',[0 0 0])
ylabel('Power (W/kg)', 'FontSize',10)
xlabel('% Gait', 'FontSize',10)
legend('ESR','AAP','Location','southeast')

% add letters to plot
for ii = 1:6
    subplot(3,2,ii)
    if (ii == 1)
        yy = 5;
    end
    if (ii == 2)
        yy = 0.04;
    end
    if (ii == 3)
        yy = 1;
    end
    if (ii == 4)
        yy = 15;
    end
    if (ii == 5)
        yy = 0.2;
    end
    if (ii == 6)
        yy = 0.5;
    end
    text(100,yy,['(',char(ii+96),') '],...
        'HorizontalAlignment','right',...
        'VerticalAlignment','top',...
        'color','r',...
        'fontw','b')
end


%% GRF grid plot
stance = 0:1:100;
clc
close all

% figure('OuterPosition',[20 20 1500 850])
figure('OuterPosition',[20 20 550 550])

subplot(2,2,1)
hold on
plot(stance,data.GRF{2,5}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.GRF{3,5}(:,1),'LineWidth',2.0,'Color',[0 0 0])
title('Prosthetic', 'FontSize',10)
ylabel('Vertical GRF (N/kg)', 'FontSize',10)
subplot(2,2,2)
hold on
plot(stance,data.GRF{2,9}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.GRF{3,9}(:,1),'LineWidth',2.0,'Color',[0 0 0])
title('Intact', 'FontSize', 10)
% legend('ESR','AAP','Location','northeast')

subplot(2,2,3)
hold on
plot(stance,data.GRF{2,4}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.GRF{3,4}(:,1),'LineWidth',2.0,'Color',[0 0 0])
ylabel('Horizontal GRF (N/kg)', 'FontSize',10)
xlabel('% Gait', 'FontSize',10)
ylim([-2.5 3])
% title('Left', 'FontSize',10)
subplot(2,2,4)
hold on
plot(stance,data.GRF{2,8}(:,1),'LineWidth',2.0,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.GRF{3,8}(:,1),'LineWidth',2.0,'Color',[0 0 0])
xlabel('% Gait', 'FontSize',10)
ylim([-2.5 3])
legend('ESR','AAP','Location','southeast')
% title('Right', 'FontSize', 10)

% add letters to plot
for ii = 1:4
    subplot(2,2,ii)
    if (ii == 1)
        yy = 15;
    end
    if (ii == 2)
        yy = 15;
    end
    if (ii == 3)
        yy = 3;
    end
    if (ii == 4)
        yy = 3;
    end
    text(100,yy,['(',char(ii+96),') '],...
        'HorizontalAlignment','right',...
        'VerticalAlignment','top',...
        'color','r',...
        'fontw','b')
end
%% COM plot

% close all
clc

% Torso
% figure('OuterPosition',[20 20 1500 850])
% hold on
% plot(stance,data.COM.TorsoCOM{2,3}(:,1),'LineWidth',3,'Color',[0 0 0],'LineStyle',':')
% plot(stance,data.COM.TorsoCOM{3,3}(:,1),'LineWidth',3,'Color',[0 0 0])
% ylabel('Y Coordinate (m)', 'FontSize',18)
% title('Torso COM trajectory', 'FontSize',20)
% legend('ESR','AAP','Location','northeast')

% figure('OuterPosition',[20 20 1500 850])
figure('OuterPosition',[20 20 550 300])

% subplot(3,2,5)
hold on
plot(stance,data.COM.CombinedCOM{2,3}(:,1),'LineWidth',3,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.COM.CombinedCOM{3,3}(:,1),'LineWidth',3,'Color',[0 0 0])
ylabel('Y Coordinate (m)', 'FontSize',10)
title('COM trajectory', 'FontSize',10)
legend('ESR','AAP','Location','southeast')
xlabel('% Gait', 'FontSize',10)
ylim([-0.06 0.01])

%% Pressure  plots

stance = 0:1:100;
% figure('OuterPosition',[20 20 1500 850])
figure('OuterPosition',[20 20 550 550])

subplot(2,2,1)
hold on
plot(stance,data.Pressure{2,4}(:,1),'LineWidth',2.5,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.Pressure{3,4}(:,1),'LineWidth',2.5,'Color',[0 0 0])
title('Sensor 1 on Tibial Tubercle', 'FontSize',10)
ylabel('Avg Pressure (kPa)', 'FontSize',10)
% ylim([0 75])

subplot(2,2,2)
hold on
plot(stance,data.Pressure{2,5}(:,1),'LineWidth',2.5,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.Pressure{3,5}(:,1),'LineWidth',2.5,'Color',[0 0 0])
title('Sensor 2 on Limb Posterior', 'FontSize',10)
legend('ESR','AAP','Orientation','horizontal','Location','northeast')

subplot(2,2,3)
hold on
plot(stance,data.Pressure{2,6}(:,1),'LineWidth',2.5,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.Pressure{3,6}(:,1),'LineWidth',2.5,'Color',[0 0 0])
ylabel('Peak Pressure (kPa)', 'FontSize',10)
xlabel('% Gait', 'FontSize',10)
ylim([0 120])

subplot(2,2,4)
hold on
plot(stance,data.Pressure{2,7}(:,1),'LineWidth',2.5,'Color',[0 0 0],'LineStyle',':')
plot(stance,data.Pressure{3,7}(:,1),'LineWidth',2.5,'Color',[0 0 0])
xlabel('% Gait', 'FontSize',10)

% add letters to plot
for ii = 1:4
    subplot(2,2,ii)
    if (ii == 1)
        yy = 80;
    end
    if (ii == 2)
        yy = 80;
    end
    if (ii == 3)
        yy = 120;
    end
    if (ii == 4)
        yy = 80;
    end
    text(100,yy,['(',char(ii+96),') '],...
        'HorizontalAlignment','right',...
        'VerticalAlignment','top',...
        'color','r',...
        'fontw','b')
end
